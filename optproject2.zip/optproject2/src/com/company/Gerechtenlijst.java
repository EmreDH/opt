package com.company;

import java.util.ArrayList;

public class Gerechtenlijst {
    private ArrayList<String> gerechten;

    public Gerechtenlijst() {
        gerechten = new ArrayList<>();
    }

    public void voegGerechtToe(String gerechtNaam) {
        gerechten.add(gerechtNaam);
    }

    public void verwijderGerecht(String gerechtNaam) {
        gerechten.remove(gerechtNaam);
    }

    public void verwijderAlleGerechten() {
        gerechten.clear();
    }

    public void willekeurigGerecht(Klant klant) {
        String willekeurigGerecht = gerechten.get((int) (Math.random() * gerechten.size()));
        System.out.println(String.format("Hoi %s, je willekeurig gerecht is %s.", klant.getName(), willekeurigGerecht));
    }

    public ArrayList<String> getGerechten() {
        return gerechten;
    }
}
