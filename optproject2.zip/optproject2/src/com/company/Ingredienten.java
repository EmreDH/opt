package com.company;

public class Ingredienten {
    private String naam;

    public Ingredienten(String naam){
        this.naam = naam;
    }
    public String getNaam(){
        return naam;
    }
    public void setNaam(){
        this.naam = naam;
    }
}