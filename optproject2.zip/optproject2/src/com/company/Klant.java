package com.company;

public class Klant implements ID{
    public String naam;

    public Klant(String naam){
        this.naam = naam;
    }

    @Override
    public String getName() {
        return naam;
    }
}





