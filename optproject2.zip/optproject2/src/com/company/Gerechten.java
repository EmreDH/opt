package com.company;

import java.util.ArrayList;

public class Gerechten implements ID {
    public String naam;
    public int hoeveelgram;

    public Gerechten(String naam, int hoeveelgram){
        this.naam = naam;
        this.hoeveelgram = hoeveelgram;
    }

    private ArrayList<Ingredienten> ingredient = new ArrayList<>();


    @Override
    public String getName() {
        return naam;
    }
}
