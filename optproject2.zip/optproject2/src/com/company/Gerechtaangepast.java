package com.company;

public class Gerechtaangepast extends Gerechten{

        private boolean vegetarisch;
        private boolean vegan;

        public Gerechtaangepast(String naam, int hoeveelgram, boolean vegetarisch, boolean vegan) {
            super(naam, hoeveelgram);
            this.vegetarisch = vegetarisch;
            this.vegan = vegan;
        }
    }

