package com.company;

public interface ID {
        public String getName();
}
