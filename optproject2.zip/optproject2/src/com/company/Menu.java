package com.company;

import java.util.ArrayList;
import java.util.Scanner;

public class Menu {
        Scanner scanner = new Scanner(System.in);
    public void mainMenu(){

            System.out.println("Goededag wilt u gebruik maken van de standaard-gerechtenlijst toets 1 in. Of wilt u uw eigen gerechtenlijst gebruiken toets 2");

            int input = scanner.nextInt();
            scanner.nextLine();
            if (input ==1) {
            standaardGerechten();
            } else if(input ==2) {
                eigenGerechten();
            } else {
                System.out.println("Toets getal 1 voor standaard gerechtenlijst of toets getal 2 voor je eigen gerechtenlijst");
                mainMenu();
            }
    }

    public void standaardGerechten(){
        System.out.println("voer uw naam in");
        Klant klant = new Klant(scanner.nextLine());
        Gerechtenlijst gerechtenlijst = new Gerechtenlijst();

        gerechtenlijst.voegGerechtToe("Pasta");
        gerechtenlijst.voegGerechtToe("Rijst met kip");
        gerechtenlijst.voegGerechtToe("Stampot");
        gerechtenlijst.voegGerechtToe("Burgers");
        gerechtenlijst.willekeurigGerecht(klant);

//        Gerechten Pasta = new Gerechten("Pasta",1500);
//        Ingredienten kip = new Ingredienten("Kip");
//        Ingredienten tomaat = new Ingredienten("Tomaat");
//        Ingredienten penne = new Ingredienten("Penne");
//        Ingredienten saus = new Ingredienten("Saus");
    }


    public void eigenGerechten(){
        System.out.println("voer uw naam in");
        Klant klant = new Klant(scanner.nextLine());

        Gerechtenlijst gerechtenlijst = new Gerechtenlijst();
        System.out.println(String.format("Hoi %s, typ je gerechten in en sluit af met S. of verwijder gerecht met Delete en ga verder met invullen.", klant.getName()));
        String egerecht = "";

        while (!egerecht.equals("S")) {
            egerecht = scanner.nextLine();

            if (egerecht.equals("Delete")){
                System.out.println("Welke gerecht wilt u verwijderen");
                String input = scanner.nextLine();

                gerechtenlijst.verwijderGerecht(input);

                System.out.println("Nieuwe Lijst:");
                for(String gerecht : gerechtenlijst.getGerechten()){
                    System.out.println(gerecht);
                }
                break;
            } else if(egerecht.equals("S")){
                break;
            }
            else{
                gerechtenlijst.voegGerechtToe(egerecht);
            }
        }

        gerechtenlijst.willekeurigGerecht(klant);
    }
}