package com.company;

public class Main {

    public static void main(String[] args) {

        Menu M = new Menu();
        M.mainMenu();
    }
}

        // Concepten
        // Main -> Klant -> Gerechtenlijst (EigenGrechtenlijst, StandaardGerechtenlijst) -> Gerechten (ingredient (naam, hoeveelGram)) (Salade, Soep, Pizza, Rijst, Stampot) -> Ingredienten (naam, kcal per 100 gram)
        // Main -> Menu (weergeeft informatie console logs)